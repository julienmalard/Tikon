
Bayesian estimation, particularly using Markov chain Monte Carlo (MCMC),
is an increasingly relevant approach to statistical estimation. However,
few statistical software packages implement MCMC samplers, and they are
non-trivial to code by hand. ``pymc`` is a python package that implements the
Metropolis-Hastings algorithm as a python class, and is extremely
flexible and applicable to a large suite of problems. ``pymc`` includes
methods for summarizing output, plotting, goodness-of-fit and convergence
diagnostics.

``pymc`` only requires ``NumPy``. All other dependencies such as ``matplotlib``,
``SciPy``, ``pytables``, ``sqlite`` or ``mysql`` are optional.


